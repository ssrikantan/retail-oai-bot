namespace EchoBot
{
    public class AppParameters
    {



        public static string CURRICULUM_INDEX_NAME = "";
        public static string CURRICULUM_SEMANTIC_CONFIG = "";

        public static string BANK_NAME = "";

        public static string SEMANTIC_SEARCH_ENDPOINT = "";
        public static string SEMANTIC_SEARCH_API_KEY = "";

        public static string OPEN_AI_ENDPOINT = "";

        public static string OPEN_AI_API_KEY = "";

        public static string OPEN_AI_MODEL_DEPLOYMENT_NAME = "";
        public static string OPEN_AI_MODEL_DEPLOYMENT_NAME_COMPLETIONS_END_POINT = "";

    }
}